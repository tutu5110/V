/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.mass.necc.processing;

/**
 *
 * @author tutu
 */
public class Global {
    
    public static int a;
    public int t;
    Global(){
        t = 2;
        a = 1;
    }
    
}
