/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.mass.necc.processing;

import javafx.scene.paint.Color;
import processing.core.PApplet;
/**
 *
 * @author tutu
 */
public class DrawMaster{
    PApplet parent;
    DrawMaster(PApplet p){
        parent = p;
    }
    public void drawCircle(int r, int g, int b){
        parent.strokeWeight(2);
        parent.fill(r,g,b);
        parent.ellipse(50,50,10,10);

    }
}
