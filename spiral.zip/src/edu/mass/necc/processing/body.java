/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mass.necc.processing;

import javafx.scene.paint.Color;
import processing.core.*;

/**
 *
 * @author tutu
 */
public class body extends PApplet {
    
    int ct = 1;
    
    DrawMaster dw = new DrawMaster(this);

    Global gbl = new Global();

    float rotation = 0.0005f;

    float speed = (float) 0.0005;

    float dis = 0f;

    float z = 0;

    int iteration = 15;
    
    int subdiv = 2;

    int Strokeopacity = 40;
    
    int fillOpactiy = 255;
    
    public void keyPressed() {
        if (key == '+') {
            speed += 0.001;
            println(speed);
        } else if (key == 'a') {
            z -= 5;
        } else if (key == 'd') {
            dis += 10;
            println(dis);
        }
        else if (key == 's') {
            save("re_"+ct+".tif");
            ct++;
        }
    }

    public void setup() {
        size(3600,1800);
        background(250, 250, 250);
        this.frameRate(60);
        smooth();
        fill(255,fillOpactiy);
        // dw.drawCircle(215,125,13);
        // Global.a = 2;
        // gbl.t = 1;

        //   save("image.tif");
    }

    public void draw() {
        // this.background(255, 255, 255);

        float iw = 1600;
        float ih = 1600;
        float istrokeWidth = 20;
        float w = iw;
        float h = ih;
        //speed += (float) ((float) (Math.random() * 0.0001) * Math.pow(-1, Math.floor(Math.random() * 100000)));
        rotation += speed;
        // strokeWeight((float)(istrokeWidth /(Math.pow(2, 0))));
        //  stroke(100, 100, 100);
        this.ellipseMode(CENTER);
        // this.ellipse(0, 0, w, h);
        for (int i = subdiv; i < iteration; i++) {
          stroke(100, 100, 100, 30);

            strokeWeight((float) (istrokeWidth / (Math.pow(2, i / subdiv))));
            w = (float) (iw / (Math.pow(2, i / subdiv)));
            h = (float) (ih / (Math.pow(2, i / subdiv)));
            if (i > 0) {
                for (int j = 0; j < Math.pow(2, i / subdiv); j++) {

                    pushMatrix();
                    translate(width / 2-800, height / 2);
                    rotate((i * rotation));

                    this.ellipse(-(iw / 2 - w / 2)   + j * (w), 0, w, h);
                    popMatrix();
                    //  pushMatrix();
                    // translate(width / 2, height / 2);
                    // popMatrix();

                }
            }

        }
    }

    private float confine(float a, float b) {
        if (a >= b) {
            return b;
        }
        return a;
    }
}
